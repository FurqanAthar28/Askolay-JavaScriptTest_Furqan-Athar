// class Exercise
// {
//     constructor(name,duration,catagory)
//     {
//         this.name = name;
//         this.duration = duration;
//         this.catagory = catagory;
//     }
//     ShowDetails()
//     {
//         console.log(`Name: ${this.name}, Duration: ${this.duration}, Catagory: ${this.catagory}`);
//     }
// }
// let e1=new Exercise("Pushups",15,"Strength");
// let e2=new Exercise("Running",30,"Cardio");
// console.log(e1.ShowDetails());
// console.log(e2.ShowDetails());


// TASK 2
// function ExerciseSuggestion() {
    
//     let inputExer = document.getElementById("exercise");
//     let exercisename = inputExer.value;

//     if (!exercisename) {
//         alert("Please Enter Exercise Name");
//         return;
//     }

//     let exerciseList = document.getElementById("list");
    
//     let newExercise = document.createElement("li");
//     newExercise.textContent = exercisename;
    
    
//     exerciseList.appendChild(newExercise);
    
    
//     inputExer.value = '';

    
//     alert("Exercise Added Successfully");
// }




//Task 3
// function CongratulationsMessage()
// {
//  alert("Congratulations, you’ve completed your routine!");
// }
// function CompleteRoutine(callback)
// {
//     callback();
// }
// let button=document.getElementById("cmpRout");
// button.addEventListener("click",function()
// {
//     CompleteRoutine(CongratulationsMessage);
// });


//Task 4
// async function getData() {
//     const url = " https://api.fitnessstudio.com/user/preferences"; 
//     try {
//         const response = await fetch(url);
//         if (!response.ok) {
//             throw new Error(`Response status: ${response.status}`);
//         }
//         const json = await response.json();
//         console.log(json); 

//         document.getElementById("preferences").textContent = `Your preferences: ${JSON.stringify(json)}`;
//     } catch (error) {
//         console.error(error.message);
//         document.getElementById("preferences").textContent = "Failed to fetch preferences.";
//     }
// }

// getData(); 
// TASK 5
// let ExerciseSummary=
// [
// {
//    day: "Monday",
//    exercise: "Running",
//    duration: "30 ",
// },
// {
//    day: "Tuesday",
//    exercise: "Jogging",
//    duration: "20 ",
// },
// {
//    day: "Wednesday",
//    exercise: "Cycling",
//    duration: "15 ",
// },
// {
//    day: "Thursday",
//    exercise: "Pushups",
//    duration: "17 ",
// },
// {
//    day: "Friday",
//    exercise: "Swimming",
//    duration: "25",
// },
// {
//    day: "Saturday",
//    exercise: "Weigth Lifting",
//    duration: "10",
// },
// {
//    day: "Sunday",
//    exercise: "Walking",
//    duration: "60 ",
// }
// ];
// for (let e of ExerciseSummary) 
//     {
//    console.log
//     (`Day: ${e.day}, 
//     Exercise: ${e.exercise}, 
//     Duration: ${e.duration} mins`);
//  }  




// TASK 6
async function fetchPreferences() {
    const preferencesUrl = "https://api.escuelajs.co/api/v1/products"; 
    try {
        const response = await fetch(preferencesUrl);
        if (!response.ok) {
            throw new Error("Error fetching preferences.");
        }
        const data = await response.json();
        document.getElementById("user-preferences").textContent = `Your preferences: ${JSON.stringify(data)}`;
    } catch (error) 
    {
        console.error(error.message); 
        document.getElementById("user-preferences").textContent = "Failed to fetch preferences.";
    }
}
fetchPreferences();


  